This IPython notebook prog.ipynb does not require any additional
programs.
