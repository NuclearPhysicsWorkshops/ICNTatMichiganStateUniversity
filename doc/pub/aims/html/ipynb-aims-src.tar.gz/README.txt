This IPython notebook aims.ipynb does not require any additional
programs.
